Progetto di Data visualization ad opera di Yordanov Mihail, Bosio Anna, Longo Valentina, Sauro Letterino.
Aprire il file index.html direttamente dalla cartella in cui si trova.
Per una massima resa si consiglia l’utilizzo di Chrome come browser.